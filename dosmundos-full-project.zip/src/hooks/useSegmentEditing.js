import React, { useState, useRef, useCallback } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { getLocaleString } from '@/lib/locales';
import logService from '@/lib/logService';
import { useEditorAuth } from '@/contexts/EditorAuthContext';
import { saveEditToHistory } from '@/services/editHistoryService';

const useSegmentEditing = (
  utterances, 
  onSaveEditedSegment, 
  audioRef, 
  currentLanguage,
  user,
  episodeSlug
) => {
  const [editingSegment, setEditingSegment] = useState(null);
  const [editedText, setEditedText] = useState('');
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmDialogProps, setConfirmDialogProps] = useState({});
  const [textareaRef, setTextareaRef] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const initialAudioState = useRef({ isPlaying: false, currentTime: 0 });
  const { toast } = useToast();
  const { editor, isAuthenticated, openAuthModal } = useEditorAuth();

  const handleEditSegment = useCallback((segmentToEdit) => {
    // Check authentication before allowing edit
    if (!isAuthenticated) {
      openAuthModal();
      return;
    }
    
    if (audioRef?.current) {
      initialAudioState.current = {
        isPlaying: !audioRef.current.paused,
        currentTime: audioRef.current.currentTime,
      };
    }
    setEditingSegment(segmentToEdit);
    setEditedText(segmentToEdit ? segmentToEdit.text : '');
  }, [audioRef, isAuthenticated, toast]);

  const restoreAudioState = useCallback(() => {
    if (audioRef?.current && initialAudioState.current.isPlaying && audioRef.current.paused) {
      audioRef.current.currentTime = initialAudioState.current.currentTime;
      audioRef.current.play().catch(e => console.error("Error restoring audio play state:", e));
    } else if (audioRef?.current) {
      audioRef.current.currentTime = initialAudioState.current.currentTime;
    }
  }, [audioRef]);

  const handleSaveCurrentSegmentEdit = useCallback(async () => {
    if (!editingSegment || isSaving) return;
    
    setIsSaving(true);
    try {
      const updatedSegment = { ...editingSegment, text: editedText };
      const newUtterances = utterances.map(utt =>
        (utt.id || utt.start) === (editingSegment.id || editingSegment.start) ? updatedSegment : utt
      );
      const originalSegment = utterances.find(utt => (utt.id || utt.start) === (editingSegment.id || editingSegment.start));
      
      await onSaveEditedSegment(newUtterances, 'update', originalSegment, updatedSegment);
      
      // Save to edit history if authenticated
      if (isAuthenticated && editor) {
        try {
          const segmentId = editingSegment.id || editingSegment.start;
          await saveEditToHistory({
            editorId: editor.id,
            editorEmail: editor.email,
            editorName: editor.name,
            editType: 'transcript',
            targetType: 'segment',
            targetId: `${episodeSlug}_segment_${segmentId}`,
            contentBefore: originalSegment?.text || '',
            contentAfter: editedText,
            filePath: null,
            metadata: {
              episodeSlug: episodeSlug,
              lang: currentLanguage,
              segmentId: segmentId,
              segmentStart: editingSegment.start,
              segmentEnd: editingSegment.end,
              speaker: editingSegment.speaker,
              timestamp: new Date().toISOString()
            }
          });
          console.log('[SegmentEditing] Edit saved to history');
        } catch (historyError) {
          console.error('[SegmentEditing] Failed to save edit history:', historyError);
          // Don't fail the whole operation if history save fails
        }
      }
      
      setEditingSegment(null);
      toast({
        title: getLocaleString('transcriptSegmentUpdatedTitle', currentLanguage),
        description: getLocaleString('transcriptSegmentUpdatedDesc', currentLanguage),
        className: "bg-green-600/80 border-green-500 text-white"
      });
      restoreAudioState();
    } catch (error) {
      console.error("Failed to save segment:", error);
      toast({ title: "Save Error", description: error.message, variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  }, [editingSegment, isSaving, editedText, utterances, onSaveEditedSegment, toast, currentLanguage, restoreAudioState, isAuthenticated, editor, episodeSlug]);

  const handleCancelEdit = useCallback(() => {
    setEditingSegment(null);
    restoreAudioState();
  }, [restoreAudioState]);

  const executeAction = useCallback(async (actionType, segmentToModify, textContent, cursorPos) => {
    let newUtterances;
    const originalUtterances = JSON.parse(JSON.stringify(utterances)); 
    let logEntityId = segmentToModify.id || segmentToModify.start;
    let actionDetail = {};

    switch (actionType) {
      case 'Split': {
        if (textareaRef?.current && textareaRef.current.selectionStart !== undefined) {
          cursorPos = textareaRef.current.selectionStart;
        } else if (cursorPos === undefined || cursorPos === null) {
          toast({ title: getLocaleString('errorSplittingSegment', currentLanguage), description: getLocaleString('cursorPositionRequired', currentLanguage), variant: 'destructive' });
          return;
        }
        const textBefore = textContent.substring(0, cursorPos).trim();
        const textAfter = textContent.substring(cursorPos).trim();
        // Disallow only when resulting text parts are empty. If there are no word timings, we'll split proportionally by text length.
        if (!textBefore || !textAfter) {
          toast({ title: getLocaleString('errorSplittingSegment', currentLanguage), description: getLocaleString('cannotSplitEmpty', currentLanguage), variant: 'destructive' });
          return;
        }
        if (segmentToModify.words && Array.isArray(segmentToModify.words) && segmentToModify.words.length > 0) {
          let splitWordIndex = -1;
          let cumulativeLength = 0;
          for (let i = 0; i < segmentToModify.words.length; i++) {
            cumulativeLength += segmentToModify.words[i].text.length + (i > 0 ? 1 : 0);
            if (cumulativeLength >= cursorPos) {
              splitWordIndex = i;
              break;
            }
          }
          if (splitWordIndex === -1 || splitWordIndex >= segmentToModify.words.length - 1) {
            toast({ title: getLocaleString('errorSplittingSegment', currentLanguage), description: getLocaleString('cannotSplitAtPosition', currentLanguage), variant: 'destructive' });
            return;
          }
          const wordsBefore = segmentToModify.words.slice(0, splitWordIndex + 1);
          const wordsAfter = segmentToModify.words.slice(splitWordIndex + 1);
          if (wordsBefore.length === 0 || wordsAfter.length === 0) {
            toast({ title: getLocaleString('errorSplittingSegment', currentLanguage), description: getLocaleString('cannotSplitIntoEmpty', currentLanguage), variant: 'destructive' });
            return;
          }
          const newSegment1 = { ...segmentToModify, text: textBefore, end: wordsBefore[wordsBefore.length - 1].end, words: wordsBefore, id: segmentToModify.id || `${segmentToModify.start}-split1-${Date.now()}` };
          const newSegment2 = { ...segmentToModify, start: wordsAfter[0].start, text: textAfter, words: wordsAfter, id: `${segmentToModify.start}-split2-${Date.now()}` };
          const segmentIndexInAllUtterances = utterances.findIndex(utt => (utt.id || utt.start) === (segmentToModify.id || segmentToModify.start));
          if (segmentIndexInAllUtterances === -1) return;
          newUtterances = [...utterances.slice(0, segmentIndexInAllUtterances), newSegment1, newSegment2, ...utterances.slice(segmentIndexInAllUtterances + 1)];
          actionDetail = { splitAt: cursorPos, segment1: newSegment1, segment2: newSegment2 };
        } else {
          // Fallback: no word timings available, split proportionally by text length
          const totalTrimmedLength = textBefore.length + textAfter.length;
          const ratio = totalTrimmedLength > 0 ? (textBefore.length / totalTrimmedLength) : 0.5;
          const duration = (segmentToModify.end || 0) - (segmentToModify.start || 0);
          const splitOffset = Math.round(duration * ratio);
          const splitTime = (segmentToModify.start || 0) + splitOffset;

          const newSegment1 = { ...segmentToModify, text: textBefore, end: splitTime, words: [], id: segmentToModify.id || `${segmentToModify.start}-split1-${Date.now()}` };
          const newSegment2 = { ...segmentToModify, start: splitTime, text: textAfter, words: [], id: `${segmentToModify.start}-split2-${Date.now()}` };
          const segmentIndexInAllUtterances = utterances.findIndex(utt => (utt.id || utt.start) === (segmentToModify.id || segmentToModify.start));
          if (segmentIndexInAllUtterances === -1) return;
          newUtterances = [...utterances.slice(0, segmentIndexInAllUtterances), newSegment1, newSegment2, ...utterances.slice(segmentIndexInAllUtterances + 1)];
          actionDetail = { splitAt: cursorPos, segment1: newSegment1, segment2: newSegment2, proportional: true };
        }
        break;
      }
      case 'Merge': {
        const currentSegmentIndex = utterances.findIndex(utt => (utt.id || utt.start) === (segmentToModify.id || segmentToModify.start));
        if (currentSegmentIndex <= 0) {
          toast({ title: getLocaleString('errorMergingSegment', currentLanguage), description: getLocaleString('cannotMergeFirstSegment', currentLanguage), variant: 'destructive' });
          return;
        }
        const previousSegment = utterances[currentSegmentIndex - 1];
        const mergedText = `${previousSegment.text} ${segmentToModify.text}`.trim();
        const mergedWords = [...(previousSegment.words || []), ...(segmentToModify.words || [])].sort((a, b) => a.start - b.start);
        const mergedSegment = { ...previousSegment, text: mergedText, end: segmentToModify.end, words: mergedWords, id: previousSegment.id || `${previousSegment.start}-merged-${Date.now()}` };
        newUtterances = [...utterances.slice(0, currentSegmentIndex - 1), mergedSegment, ...utterances.slice(currentSegmentIndex + 1)];
        actionDetail = { mergedWith: previousSegment.id || previousSegment.start, resultingSegment: mergedSegment };
        break;
      }
      case 'Delete': {
        newUtterances = utterances.filter(utt => (utt.id || utt.start) !== (segmentToModify.id || segmentToModify.start));
        actionDetail = { deletedSegment: segmentToModify };
        break;
      }
      default:
        return;
    }
    if (newUtterances) {
      await onSaveEditedSegment(newUtterances, actionType.toLowerCase(), segmentToModify, newUtterances.find(utt => utt.id === (actionDetail.resultingSegment?.id || actionDetail.segment1?.id) ) || null, originalUtterances);
      
      // Save to edit history if authenticated
      if (isAuthenticated && editor) {
        try {
          const segmentId = segmentToModify.id || segmentToModify.start;
          let contentBefore = segmentToModify.text;
          let contentAfter = '';
          let extraMetadata = {};
          
          // Find index for rollback positioning
          const segmentIndex = originalUtterances.findIndex(u => (u.id || u.start) === (segmentToModify.id || segmentToModify.start));

          if (actionType === 'Split') {
            contentBefore = JSON.stringify(segmentToModify); // Save full original segment
            contentAfter = `${actionDetail.segment1.text} | ${actionDetail.segment2.text}`;
            extraMetadata = { 
              segmentIndex,
              createdSegmentsCount: 2 
            };
          } else if (actionType === 'Merge') {
            // For merge, we need both segments that were merged
            const prevSeg = originalUtterances[segmentIndex - 1];
            contentBefore = JSON.stringify([prevSeg, segmentToModify]); // Save array of original segments
            contentAfter = actionDetail.resultingSegment.text;
            extraMetadata = { 
              segmentIndex: segmentIndex - 1 // Index of the first segment in the merge
            };
          } else if (actionType === 'Delete') {
            contentBefore = JSON.stringify(segmentToModify); // Save full deleted segment
            contentAfter = '[DELETED]';
            extraMetadata = { segmentIndex };
          }
          
          await saveEditToHistory({
            editorId: editor.id,
            editorEmail: editor.email,
            editorName: editor.name,
            editType: 'transcript',
            targetType: 'segment',
            targetId: `${episodeSlug}_segment_${segmentId}`,
            contentBefore: contentBefore,
            contentAfter: contentAfter,
            filePath: null,
            metadata: {
              episodeSlug: episodeSlug,
              lang: currentLanguage,
              segmentId: segmentId,
              action: actionType,
              actionDetail: actionDetail,
              timestamp: new Date().toISOString(),
              ...extraMetadata
            }
          });
          console.log(`[SegmentEditing] ${actionType} action saved to history`);
        } catch (historyError) {
          console.error('[SegmentEditing] Failed to save edit history:', historyError);
          // Don't fail the whole operation if history save fails
        }
      }
      
      setEditingSegment(null);
      restoreAudioState();
    }
  }, [utterances, onSaveEditedSegment, toast, currentLanguage, restoreAudioState, textareaRef, user, episodeSlug, isAuthenticated, editor]);

  const insertSegmentManually = useCallback(async (startSec, endSec, textContent) => {
    // Check authentication before allowing manual segment insert
    if (!isAuthenticated) {
      openAuthModal();
      return;
    }

    try {
      if (typeof startSec !== 'number' || typeof endSec !== 'number' || isNaN(startSec) || isNaN(endSec) || startSec < 0 || endSec <= startSec) {
        toast({ title: getLocaleString('errorAddingSegment', currentLanguage), description: getLocaleString('invalidTimeRange', currentLanguage), variant: 'destructive' });
        return;
      }
      const startMs = Math.round(startSec * 1000);
      const endMs = Math.round(endSec * 1000);

      // Prevent overlaps
      const overlaps = utterances.some(u => typeof u.start === 'number' && typeof u.end === 'number' && !(endMs <= u.start || startMs >= u.end));
      if (overlaps) {
        toast({ title: getLocaleString('errorAddingSegment', currentLanguage), description: getLocaleString('segmentOverlaps', currentLanguage), variant: 'destructive' });
        return;
      }

      const newSegment = {
        id: `manual-${startMs}-${Date.now()}`,
        start: startMs,
        end: endMs,
        text: (textContent || '').trim(),
        speaker: null,
        words: []
      };

      const newUtterances = [...utterances, newSegment].sort((a, b) => (a.start || 0) - (b.start || 0));
      await onSaveEditedSegment(newUtterances, 'insert', null, newSegment, utterances);
      
      // Save to edit history if authenticated
      if (isAuthenticated && editor) {
        try {
          await saveEditToHistory({
            editorId: editor.id,
            editorEmail: editor.email,
            editorName: editor.name,
            editType: 'transcript',
            targetType: 'segment',
            targetId: `${episodeSlug}_segment_${newSegment.id}`,
            contentBefore: '',
            contentAfter: textContent || '',
            filePath: null,
            metadata: {
              episodeSlug: episodeSlug,
              segmentId: newSegment.id,
              action: 'Insert',
              startMs: startMs,
              endMs: endMs,
              timestamp: new Date().toISOString()
            }
          });
          console.log('[SegmentEditing] Manual insert saved to history');
        } catch (historyError) {
          console.error('[SegmentEditing] Failed to save edit history:', historyError);
          // Don't fail the whole operation if history save fails
        }
      }
      
      toast({ title: getLocaleString('segmentAddedTitle', currentLanguage), description: getLocaleString('segmentAddedDesc', currentLanguage), className: "bg-green-600/80 border-green-500 text-white" });
    } catch (error) {
      toast({ title: getLocaleString('errorAddingSegment', currentLanguage), description: error.message, variant: 'destructive' });
    }
  }, [utterances, onSaveEditedSegment, toast, currentLanguage, isAuthenticated, editor, episodeSlug, openAuthModal]);

  const performActionWithConfirmation = useCallback((actionType, segmentToModify, textContent, cursorPos) => {
    const dontAskAgainKey = `confirm${actionType}SegmentDisabled`;
    const isDisabled = localStorage.getItem(dontAskAgainKey) === 'true';

    if (isDisabled) {
      executeAction(actionType, segmentToModify, textContent, cursorPos);
      return;
    }

    let titleKey, descriptionKey;
    switch (actionType) {
      case 'Split': titleKey = 'confirmSplitTitle'; descriptionKey = 'confirmSplitDescription'; break;
      case 'Merge': titleKey = 'confirmMergeTitle'; descriptionKey = 'confirmMergeDescription'; break;
      case 'Delete': titleKey = 'confirmDeleteSegmentTitle'; descriptionKey = 'confirmDeleteSegmentDescription'; break;
      default: return;
    }

    setConfirmDialogProps({
      title: getLocaleString(titleKey, currentLanguage),
      description: getLocaleString(descriptionKey, currentLanguage),
      onConfirm: () => {
        executeAction(actionType, segmentToModify, textContent, cursorPos);
        setShowConfirmDialog(false);
      },
      onCancel: () => setShowConfirmDialog(false),
      actionType
    });
    setShowConfirmDialog(true);
  }, [executeAction, currentLanguage]);

  return {
    editingSegment,
    setEditingSegment,
    editedText,
    setEditedText,
    showConfirmDialog,
    confirmDialogProps,
    textareaRef, 
    setTextareaRef,
    handleEditSegment,
    handleSaveCurrentSegmentEdit,
    handleCancelEdit,
    performActionWithConfirmation,
    setShowConfirmDialog,
    isSaving,
    insertSegmentManually,
  };
};

export default useSegmentEditing;